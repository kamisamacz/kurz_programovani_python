from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button

class WorkerView(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(orientation='vertical', **kwargs)
        self.add_widget(Button(
            text="Complete Order",
            size_hint=(1, None),
            height=50,
            on_press=self.complete_order
        ))

    def complete_order(self, instance):
        print("[WORKER] Completing an order...")
