from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button

class UserView(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(orientation='vertical', **kwargs)
        # Přidáme tlačítko s pevnou výškou
        self.add_widget(Button(
            text="Create Order",
            size_hint=(1, None),  # Pevná výška
            height=50,           # Nastavení výšky tlačítka
            on_press=self.create_order
        ))

    def create_order(self, instance):
        print("[USER] Creating an order...")
