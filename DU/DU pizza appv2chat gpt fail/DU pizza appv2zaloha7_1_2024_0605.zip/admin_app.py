from kivy.app import App
from pizza_app.views.AdminView import AdminView

class AdminApp(App):
    def build(self):
        print("Admin App loaded successfully.")
        return AdminView()

if __name__ == "__main__":
    AdminApp().run()
