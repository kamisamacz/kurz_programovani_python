from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label

class AdminView(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.orientation = "vertical"
        self.padding = 10
        self.spacing = 10

        # Přidání obsahu aplikace
        self.add_widget(Label(text="Admin Panel", size_hint=(1, 0.9)))

        # Box pro tlačítka
        button_box = BoxLayout(orientation="horizontal", size_hint=(1, 0.1), spacing=10)
        button_box.add_widget(Button(text="Add 5 Min", size_hint_y=None, height=40))
        button_box.add_widget(Button(text="Cancel Order", size_hint_y=None, height=40))
        self.add_widget(button_box)
