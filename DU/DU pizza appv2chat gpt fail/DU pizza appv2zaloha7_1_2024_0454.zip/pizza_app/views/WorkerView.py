from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label

class WorkerView(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.orientation = "vertical"
        self.padding = 10
        self.spacing = 10

        # Přidání obsahu aplikace
        self.add_widget(Label(text="Worker Panel", size_hint=(1, 0.9)))

        # Box pro tlačítka
        button_box = BoxLayout(orientation="horizontal", size_hint=(1, 0.1), spacing=10)
        button_box.add_widget(Button(text="Mark as Done", size_hint_y=None, height=40))
        self.add_widget(button_box)
