import json
from threading import Lock

class OrderStorage:
    _file_path = "orders.json"
    _lock = Lock()

    @staticmethod
    def load_orders():
        print("Loading orders from file...")
        try:
            with open(OrderStorage._file_path, "r") as file:
                return json.load(file)
        except (FileNotFoundError, json.JSONDecodeError):
            print("No orders found.")
            return []

    @staticmethod
    def save_orders(orders):
        print("Saving orders to file...")
        with open(OrderStorage._file_path, "w") as file:
            json.dump(orders, file, indent=4)
